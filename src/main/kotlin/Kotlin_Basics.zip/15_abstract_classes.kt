/*
classes without body and code. What needs to be done, not how.
 */

abstract class vehicle() {
    abstract fun move()
    abstract fun stop()
}

class car(): vehicle(){
    override fun move(){

    }
    override fun stop(){

    }
}
